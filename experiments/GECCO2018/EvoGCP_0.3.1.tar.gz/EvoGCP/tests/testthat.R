library(testthat)
library(EvoGCP)

test_check("EvoGCP")
